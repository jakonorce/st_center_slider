import os
# st_center_slider/__init__.py
from __future__ import annotations

from pathlib import Path
from typing import Any, Optional, Tuple

import streamlit as st
import streamlit.components.v1 as components

# Build ships the static frontend; dev server only when hacking locally
_RELEASE: bool = True
_COMPONENT_NAME = "st_center_slider"

_pkg_dir = Path(__file__).resolve().parent
_build_dir = _pkg_dir / "frontend" / "dist"

if not _RELEASE:
    _component_func = components.declare_component(_COMPONENT_NAME, url="http://localhost:3000")
else:
    _component_func = components.declare_component(_COMPONENT_NAME, path=str(_build_dir))

# --- Truly Stateless Range Slider (Final Version) ---
def range_slider(
    label,
    min_value=0.0,
    max_value=100.0,
    value=(25.0, 75.0),
    step=0.1,
    update_on_release=True,
    height=30,
    # New customization options
    inline_layout=True,
    show_range_values=False,
    show_center_range=True,
    unit=None,
    append_unit=True,
    # Color customization options
    track_color="#ffebee",
    line_color="#f44336",
    handle_color="#d32f2f",  # Min/max handle color
    center_handle_color=None,  # If None, uses darker version of handle_color
    text_color=None,  # If None, uses center_handle_color
    center_value_color=None,  # If None, uses text_color (for center value like "62")
    center_range_color=None,  # If None, uses text_color (for +/-XX display)
    unit_color=None,  # If None, uses text_color (for unit display)
    # Distribution visualization options
    show_distribution=False,  # If True, shows distribution curve above track
    distribution_type="gaussian",  # Type of distribution: "gaussian", "gaussian1sigma", or "uniform"
    distribution_color=None,  # If None, uses light grey for default
    # Label sizing options (inline layout)
    label_width_px=100,
    label_width_percent=10,
    label_min_px=None,
    label_max_px=None,
    label_max_lines=2,
    # Slider sizing
    min_slider_width_px=None,
    key=None
):
    """A truly stateless range slider component."""
    
    # The component's label
    #st.markdown(
    #    f'<p style="font-family: \'Source Sans 3\', sans-serif; font-size: 14px; font-weight: 200; color: var(--text-color); margin-bottom: 0.25rem;">{label}</p>', 
    #    unsafe_allow_html=True
    #)

    def _snap_to_step(num):
        if not step: 
            return num
        return round((num - min_value) / step) * step + min_value

    # Initialize from session_state if present (tuple/list expected), else from value
    session_tuple = None
    if key and key in st.session_state:
        v = st.session_state[key]
        if isinstance(v, (tuple, list)) and len(v) == 2:
            session_tuple = (float(v[0]), float(v[1]))

    base_tuple = session_tuple if session_tuple is not None else (value[0], value[1])

    initial_lower = _snap_to_step(base_tuple[0])
    initial_upper = _snap_to_step(base_tuple[1])
    initial_center = (initial_lower + initial_upper) / 2
    initial_range = (initial_upper - initial_lower) / 2
    
    # Handle center handle color defaulting - if None, make it darker than handle_color
    def darken_color(color, amount):
        """Darken a hex color by the given amount (0-1)"""
        hex_val = color.replace('#', '')
        r = max(0, int(hex_val[0:2], 16) - int(255 * amount))
        g = max(0, int(hex_val[2:4], 16) - int(255 * amount))
        b = max(0, int(hex_val[4:6], 16) - int(255 * amount))
        return f"#{r:02x}{g:02x}{b:02x}"

    final_center_handle_color = center_handle_color if center_handle_color is not None else darken_color(handle_color, 0.2)

    # Handle text color - use provided value or default to center handle color
    final_text_color = text_color if text_color is not None else final_center_handle_color

    # Handle center value color - use provided value or default to text color
    final_center_value_color = center_value_color if center_value_color is not None else final_text_color

    # Handle center range color - use provided value or default to text color
    final_center_range_color = center_range_color if center_range_color is not None else final_text_color

    # Handle unit color - use provided value or default to text color
    final_unit_color = unit_color if unit_color is not None else final_text_color

        # Handle distribution color - use provided value or default to dark grey
    final_distribution_color = distribution_color if distribution_color is not None else "rgba(80, 80, 80, 0.25)"

    # Call the component - it manages its own state after initialization
    component_return_value = _component_func(
        label=label,
        center_value=initial_center,
        range_value=initial_range,
        min_val=min_value,
        max_val=max_value,
        step=step,
        update_on_release=update_on_release,
        height=height,
        inline_layout=inline_layout,
        show_range_values=show_range_values,
        show_center_range=show_center_range,
        unit=unit,
        append_unit=append_unit,
        track_color=track_color,
        line_color=line_color,
        handle_color=handle_color,
        center_handle_color=final_center_handle_color,
        text_color=final_text_color,
        center_value_color=final_center_value_color,
        center_range_color=final_center_range_color,
        unit_color=final_unit_color,
        show_distribution=show_distribution,
        distribution_type=distribution_type,
        distribution_color=final_distribution_color,
        label_width_px=label_width_px,
        label_width_percent=label_width_percent,
        label_min_px=label_min_px,
        label_max_px=label_max_px,
        label_max_lines=label_max_lines,
        min_slider_width_px=min_slider_width_px,
        key=key,
        default=[initial_lower, initial_upper]
    )

    # Return the component's value, or initial if not available
    if component_return_value is not None:
        return (component_return_value[0], component_return_value[1])
    
    return (initial_lower, initial_upper)


# --- Example Usage ---
if __name__ == "__main__":
    st.set_page_config(layout="centered")
    st.title("Custom Range Slider")

    # Functionality to reset sliders
    if st.button("Reset Sliders"):
        st.session_state["my_slider_step"] = (25, 75)
        st.session_state["my_slider_step2"] = (25, 75)
        st.session_state["blue_slider"] = (20, 80)
        st.session_state["green_slider"] = (30, 70)
        st.session_state["purple_slider"] = (10, 90)
        st.session_state["simple_text_slider"] = (50, 50)
        st.session_state["custom_text_slider"] = (25, 75)
        st.session_state["auto_center_slider"] = (40, 60)
        st.session_state["gaussian_slider"] = (25, 75)
        st.session_state["gaussian1sigma_slider"] = (40, 60)
        st.session_state["uniform_slider"] = (20, 80)
        st.session_state["center_range_slider"] = (35, 65)
        st.session_state["standard_slider"] = (25, 75)
        st.rerun()
    

    values = range_slider(
        "Choose min and max values (MHz)",
        min_value=0,
        max_value=100,
        value=(25, 75),
        step=0.1,
        update_on_release=True,
        show_distribution=True,
        distribution_type="uniform",
        key="my_slider_step"
    )

    values2 = range_slider(
        "Slider2 [s]",
        min_value=0,
        max_value=100,
        value=(25, 75),
        show_distribution=True,  # Enable Gaussian curve
        step=0.1,
        update_on_release=True,
        key="my_slider_step2"
    )

    # Example with custom colors - Blue theme (center handle darker than min/max)
    values_blue = range_slider(
        "Blue Theme Slider with range values",
        min_value=0,
        max_value=100,
        value=(20, 80),
        step=1,
        height=30,
        track_color="#e3f2fd",
        show_distribution=True,  # Enable Gaussian curve
        show_range_values=True,
        line_color="#2196f3",
        handle_color="#1976d2",  # Min/max handles - lighter
        center_handle_color="#0d47a1",  # Center handle - darker
        key="blue_slider"
    )

    # Example with custom colors - Green theme
    values_green = range_slider(
        "Green Theme Slider",
        min_value=0,
        max_value=100,
        value=(30, 70),
        step=1,
        show_distribution=True,  # Enable Gaussian curve
        track_color="#e8f5e8",
        line_color="#4caf50",
        handle_color="#388e3c",  # Min/max handles - lighter
        center_handle_color="#2e7d32",  # Center handle - darker
        key="green_slider"
    )

    # Example with custom colors - Purple theme
    values_purple = range_slider(
        "Purple Theme Slider",
        min_value=0,
        max_value=100,
        value=(10, 90),
        step=1,
        track_color="#f3e5f5",
        line_color="#9c27b0",
        handle_color="#7b1fa2",  # Min/max handles - lighter
        center_handle_color="#4a148c",  # Center handle - darker
        key="purple_slider"
    )

    # Example showing text_color working independently (no center_handle_color)
    values_simple_text = range_slider(
        "Simple Text Color - Red text (independent of handles)",
        min_value=0,
        max_value=100,
        value=(50, 60),
        step=1,
        track_color="#f0f0f0",
        line_color="#cccccc",
        handle_color="#cccccc",
        # center_handle_color not specified - will be auto-darkened
        text_color="#ff0000",  # Red text - should work independently!
        unit="MHz",
        key="simple_text_slider"
    )

    # Example with granular text color control
    values_custom_text = range_slider(
        "Granular Text Colors",
        min_value=0,
        max_value=100,
        value=(25, 75),
        step=1,
        track_color="#eeeeee",
        line_color="#ff0000",
        handle_color="#aaaaaa",  # Min/max handles - grey
        center_handle_color="#000000",  # Center handle - black
        text_color="#666666",  # Default text color (grey)
        center_value_color="#000000",  # Center value (62) - black
        #center_range_color="#bbbbbb",  # Center range (+/-13) - grey
        unit_color="#000000",  # Units - black
        unit="units",
        key="custom_text_slider"
    )

    # Example showing automatic center handle darkening
    values_auto_center = range_slider(
        "Auto Center Darkening",
        min_value=0,
        max_value=100,
        value=(40, 60),
        step=1,
        show_distribution=True,
        distribution_type="uniform",
        handle_color="#00aa00",  # Min/max handles - green
        # center_handle_color not specified - will be darker green automatically
        key="auto_center_slider"
    )

    # Example with Gaussian distribution visualization
    values_gaussian = range_slider(
        "Gaussian Distribution, ±2σ = 95.4%",
        min_value=0,
        max_value=100,
        value=(25, 75),
        step=1,
        track_color="#e8eaf6",
        line_color="#3f51b5",
        handle_color="#3f51b5",
        show_distribution=True,  # Enable distribution curve
        distribution_type="gaussian",  # ±2σ range (95.4% confidence)
        distribution_color="rgba(156, 39, 176, 0.2)",  # Light transparent purple fill
        height=60,  # Height to accommodate text + curve
        key="gaussian_slider"
    )

    # Example with Gaussian 2σ distribution visualization
    values_gaussian1sigma = range_slider(
        "Gaussian Distribution, ±1σ = 68.3%",
        min_value=0,
        max_value=100,
        value=(40, 60),
        step=1,
        show_distribution=True,  # Enable distribution curve
        distribution_type="gaussian1sigma",  # ±2σ range (95.4% confidence)
        height=60,
        key="gaussian1sigma_slider"
    )

    # Example with Uniform distribution visualization
    values_uniform = range_slider(
        "Uniform Distribution",
        min_value=0,
        max_value=100,
        value=(20, 80),
        step=1,
        track_color="#f0f8ff",
        line_color="#2196f3",
        handle_color="#2196f3",
        show_distribution=True,  # Enable distribution curve
        distribution_type="uniform",  # Rectangle distribution
        distribution_color="rgba(33, 150, 243, 0.3)",  # Light blue fill
        height=60,
        key="uniform_slider"
    )

    # Example with custom center range color (lighter to stand out)
    values_center_range = range_slider(
        "Custom Center Range Color, not inline",
        min_value=0,
        max_value=100,
        value=(35, 65),
        step=1,
        inline_layout=False,
        track_color="#f0f0f0",
        line_color="#666666",
        handle_color="#666666",
        show_distribution=True,  # Enable Gaussian curve
        text_color="#333333",
        center_range_color="#007acc",  # Lighter blue for +/-XX text
        unit="MHz",
        key="center_range_slider"
    )

    st.subheader("Selected Values:")
    st.write(f"Slider 1: **{values[0]}** to **{values[1]}**")
    st.write(f"Slider 2: **{values2[0]}** to **{values2[1]}**")
    st.write(f"Blue Slider: **{values_blue[0]}** to **{values_blue[1]}**")
    st.write(f"Green Slider: **{values_green[0]}** to **{values_green[1]}**")
    st.write(f"Purple Slider: **{values_purple[0]}** to **{values_purple[1]}**")
    st.write(f"Simple Text Color: **{values_simple_text[0]}** to **{values_simple_text[1]}**")
    st.write(f"Custom Text Slider: **{values_custom_text[0]}** to **{values_custom_text[1]}**")
    st.write(f"Auto Center Slider: **{values_auto_center[0]}** to **{values_auto_center[1]}**")
    st.write(f"Gaussian Slider: **{values_gaussian[0]}** to **{values_gaussian[1]}**")
    st.write(f"Gaussian 1σ Slider: **{values_gaussian1sigma[0]}** to **{values_gaussian1sigma[1]}**")
    st.write(f"Uniform Slider: **{values_uniform[0]}** to **{values_uniform[1]}**")
    st.write(f"Center Range Color: **{values_center_range[0]}** to **{values_center_range[1]}**")



    st.title("Standard Slider")



    # For comparison with the standard slider
    st_values = st.slider(
        "Choose min and max values (Standard Slider)",
        min_value=0,
        max_value=100,
        step=1,
        value=(25, 75),
        key="standard_slider"
    )
    st.subheader("Selected Values:")
    st.write(f"You chose the range: **{st_values[0]}** to **{st_values[1]}**")


